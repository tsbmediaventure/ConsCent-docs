
#import <Foundation/Foundation.h>

//! Project version number for CCPlugin.
FOUNDATION_EXPORT double CCPluginVersionNumber;

//! Project version string for CCPlugin.
FOUNDATION_EXPORT const unsigned char CCPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CCPlugin/PublicHeader.h>


