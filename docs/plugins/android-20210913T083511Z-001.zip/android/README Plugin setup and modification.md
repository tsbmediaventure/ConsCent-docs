Conscent Plugin
======================

This is a step by step guide for managing Conscent Plugin and its related sub-classes. This plugin is developed in Kotlin and supports both Java and Kotlin languages. 

###
Open project in Android Studio. Let Android Studio compile it, include all dependencies of sdk as provided by Android Studio for functioning of plug-in. When project is compiled, hit clean and build. After above process, the project is ready to use.
For generating new aar file, either run your project, build your project or run "gradlew assemble" in terminal inside root folder. After successful completion, check plugin directory. aar file will be available inside "ConScent\plugin\build\outputs\aar" path whenever project is build successfully. 

### 
External dependencies used

* Retrofit with GSON converter
Latest retrofit libraries are used for API handling.
More info at: https://square.github.io/retrofit/

* Coroutines
Kotlin coroutines are used for handling all asynchronous work.
More info at: https://developer.android.com/kotlin/coroutines

* Custom tab Browser
This library is used to have full and updated support of Android OS for handling all web related work in user's default browser. Browser is used as it provides more performance & security enhancements in transactions as it's security is handled by Android OS itself which far more superior than regular webview.
More info at: https://developer.android.com/jetpack/androidx/releases/browser

## 
For inclusion of plugin in any 3rd party project, please check README_Dev.md file.

### Packages information:
* activites
This package contains files which are required for handling callbacks and launching payment process in custom tab browser.

Files available:
CustomTabsManagerActivity.kt
CustomTabsRedirectActivity.kt


* api
This package contains files which contains information related to API calls to be made for checking user & content information.

Files available:
ApiHelper.kt
This file contains information related to methods to make API calls via an API service class.

ApiService.kt
This file contains all information for all APIs end-point, API method used and parameters to be passed.

RetrofitBuilder.kt
This class generates retrofit instance to make API calls. 


* helpers
This package contains all files related to helper classes used for plugin which are required for managing and providing data for smooth functioning.
Files available
AppConstants.kt
This file contains all constants used in app and all base url.

AppSharedPreferences.kt
This file is responsible for saving data in app's shared preferences and managing it.

Conscent.kt
This is the main class which contains all methods for making API calls, user passed data check and all exposed methods for checking content ids and handling. For more information, check README_Dev.md file for exposed methods provided.

* repository
This package contain file named MainRepository.kt which is responsible for invoking and managing API calls based on ApiHelper.kt  

* models
This package contains file Model.kt which contains all data classes used inside app i.e. used in API calling request, response handling and intenal to plug-in functionality.

## Internal data classes

ContentCheckResponse
This is the response class for API content check.

ConsumptionCheckRequest
This is the request class used in free-consumption API.

ContentConsumptionCheckResponse
This is the response class for free-consumption API.

CreateLCResponse
This is the request & response class for creating login challenge.

LCResponse
This is the response class for checking user's login challenge.

CheckContentResponse
This class is the response for checking user's session for a particular content.

AuthHandler
This file is responsible for retaining user related data passed for layouts, view-ids, calling activity information, colors and fab view. 


* framework
This package contains files responsible for handling app client information, app context, encoding/decoding in binary format, etc. 

Internal packages
* auth
Files available:
AppClient.kt
This file contain & retain information passed via Application class related to app client being used and app modes. 

AppContext.kt
This file contain & retain information related to app context passed via Application class. 

* core
ConsCentConfiguration.kt
This file contains information related to client id and based on it, provides url related to environment set.




======================End======================